Código obtenido de http://martin.com.uy.

Se permite su uso, modificación y distribución (con fines comerciales o no-comerciales) siempre que se incluya una referencia al sitio original (http://martin.com.uy).
