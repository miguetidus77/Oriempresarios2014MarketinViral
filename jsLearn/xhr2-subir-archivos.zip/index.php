<!doctype html>
<html>
<head>
	<title>Cargando archivos con XMLHttpRequest 2</title>
</head>
<body>
	<input type="file" id="archivo"/>

	<script src="js/test.js"></script>
	
</body>
</html>